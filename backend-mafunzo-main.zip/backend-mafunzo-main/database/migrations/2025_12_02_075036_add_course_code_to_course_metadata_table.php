<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        // Modify the enum to include 'course_code'
        DB::statement("ALTER TABLE course_metadata MODIFY COLUMN type ENUM('name', 'course_type', 'location', 'course_code')");
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Revert back to original enum
        DB::statement("ALTER TABLE course_metadata MODIFY COLUMN type ENUM('name', 'course_type', 'location')");
    }
};
